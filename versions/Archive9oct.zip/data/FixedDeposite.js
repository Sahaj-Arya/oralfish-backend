const FixedDeposit = [
  {
    fixed_id: 3,
    id: 3,
    title: "Fixed Deposite",
    bank_id: 12,
    deposit_range: "300-200",
    tenure_range: "500-600",
    intrest_rate: "50%",
    apply_link: "http://hello.com",
    bank_image:
      "images/fixed/202206200927indusAura Edge_card-image_396x257px.png",
    desc: "<p>xfsdgdf</p>",
    rank: 14,
    deleted_at: null,
    created_at: "2022-06-20T14:57:53.000000Z",
    updated_at: "2023-07-26T12:42:28.000000Z",
    bank_name: "AXIS BANK",
  },
];
